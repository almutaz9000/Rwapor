---
name: Rwapor Developer
description: >
  This skill should be used when working on the Rwapor R package — an FAO WaPOR
  and AgERA5 data access tool with Shiny dashboard. Trigger when the user mentions
  "Rwapor", "WaPOR R package", "run_wapor", "wapor_map", "wapor_ts", "seasonal
  analysis", "crop water productivity", "AETI", "ETc", "Kc curve", "Peff", "adequacy",
  "CWP", "BWP", "crop mask", "plan_wapor_time_slices", "L3 regions", "AgERA5",
  "the dashboard", "analysis tab", "download module", "seasonal logic", or asks
  to "fix bug in Rwapor", "add feature to dashboard", "improve Shiny UI", "refactor
  analysis code", or "review Rwapor function". MUST load BEFORE writing, editing,
  or reviewing ANY Rwapor code.
version: 1.1.0
---

# Rwapor Developer Skill

Lead developer skill for the **Rwapor** R package — an FAO tool for downloading
and processing WaPOR and AgERA5 data with a built-in Shiny dashboard for seasonal
crop water productivity analysis.

- **Version**: 0.1.0 (experimental)
- **GitHub**: https://github.com/almutaz9000/Rwapor
- **License**: MIT
- **Entry point**: `run_wapor()` launches the Shiny dashboard
- **R >= 4.1.0** required

---

## Critical: Pre-Code Workflow

**Before writing or editing ANY code, always:**

1. Identify which module the change affects (API, download, analysis, dashboard, utilities)
2. Load the appropriate modular reference file(s) from `references/`:
   - `core-api.md` — API client, metadata, variable definitions
   - `download-pipeline.md` — wapor_map, wapor_ts, planning, seasonal download
   - `analysis-pipeline.md` — Crop mask, Kc, ETc, AETI, Peff, adequacy, CWP/BWP
   - `shiny-dashboard.md` — UI modules, dashboard structure, reactive patterns
   - `utilities.md` — Utils, GDAL config, unit conversion, crop defaults
3. Load `bug-log.md` to check for known issues in that area
4. Load `feature-log.md` to check if this is a tracked request
5. Output the **DEV BRIEF block** (see below)
6. Then and only then write code

**Never skip this workflow.** It prevents regressions and ensures consistency.

---

## Mandatory Pre-Code Declaration

Before EVERY code change, output:

```
📦 RWAPOR DEV BRIEF
─────────────────────────────────────────
Module              : [Core API | Download | Analysis | Dashboard | Utilities]
Affected file(s)    : <R/filename.R or inst/shiny/mod_*.R>
Affected function(s): <function_name()>
Change type         : [Bug Fix | Feature | Refactor | UI/UX | Method]
Related log entry   : [Bug #N | Feature #N | none]
Known constraints   : <relevant patterns from logs>
─────────────────────────────────────────
```

---

## Modular Reference Files — When to Load

Load **only what's needed** per task to optimize token usage:

| Task Type | Load These Files |
|---|---|
| API or metadata work | `core-api.md` + `bug-log.md` |
| Download function fix | `download-pipeline.md` + `bug-log.md` |
| Analysis indicator issue | `analysis-pipeline.md` + `bug-log.md` |
| Shiny UI/UX change | `shiny-dashboard.md` + `ui-decisions.md` |
| Utility function work | `utilities.md` + `bug-log.md` |
| New feature request | Check `feature-log.md` first, then load relevant module(s) |
| Bug triage (file unknown) | Start with `bug-log.md`, then load specific module |

**Full context (all 5 modules + logs)** only when:
- Implementing cross-cutting features
- Major refactoring across multiple files
- Onboarding to unfamiliar codebase area

---

## Package Structure Quick Reference

```
Rwapor/
├── R/
│   ├── api_client.R           → core-api.md
│   ├── metadata.R             → core-api.md
│   ├── wapor_map.R           → download-pipeline.md
│   ├── wapor_ts.R            → download-pipeline.md
│   ├── plan_wapor_time_slices.R  → download-pipeline.md
│   ├── seasonal_download.R   → download-pipeline.md
│   ├── analysis.R            → analysis-pipeline.md
│   ├── analysis_indicators.R → analysis-pipeline.md
│   ├── unit_convertor.R      → utilities.md
│   ├── utils.R               → utilities.md
│   ├── gdal_config.R         → utilities.md
│   ├── crop_defaults.R       → utilities.md
│   ├── rwapor_favorites.R    → utilities.md
│   └── run_dashboard.R       → shiny-dashboard.md
├── inst/shiny/
│   ├── app.R                  → shiny-dashboard.md
│   ├── mod_*.R                → shiny-dashboard.md
│   └── utils_shiny.R          → shiny-dashboard.md
├── fao_crop_coefficients.csv  → analysis-pipeline.md
└── fao_growth_stages.csv      → analysis-pipeline.md
```

---

## Coding Standards (TL;DR)

- **Tidyverse style guide** — snake_case, 2-space indent
- **terra** for rasters (never deprecated `raster` package)
- **sf** for vectors
- **exactextractr** for pixel-weighted zonal stats
- **httr2** for API calls
- Roxygen2 docs on all exported functions
- `tryCatch()` on all I/O and API calls
- No hardcoded paths
- Package-exported functions prefixed with `rwapor_` (except: `wapor_map`, `wapor_ts`, `run_wapor`)

---

## Key Methodological References

- **WaPOR ETLook**: https://bitbucket.org/cioapps/wapor-et-look/wiki/Home
- **PyWaPOR**: https://bitbucket.org/cioapps/pywapor/src/master/
- **FAO-56** (Allen et al. 1998): Kc, ETc, Peff (USDA SCS method)
- **FAO WaPOR portal**: https://www.fao.org/in-action/remote-sensing-for-water-productivity/

---

## Memory Update Protocol

After any confirmed fix, feature, or decision, update the appropriate log:

> "📝 Logging to [log-file]: [entry summary]"

**Rules:**
- One entry per event
- Include function + file
- Be specific (exact approach, not just "it worked")
- Never invent entries

---

## Conflict Escalation

If a change contradicts a confirmed log entry, flag it before proceeding:

> "⚠️ Conflict with [log file, entry N]: [description]. Confirm before I continue."

---

## Context Brief (Auto-Generated)

At the start of relevant Rwapor tasks, output a brief orientation:

```
🔍 RWAPOR CONTEXT
• Working on     : <module/file/function>
• Current state  : <what it does now>
• Open issues    : <known bugs/limitations if any>
• Last confirmed : <relevant working pattern from logs>
```

Omit lines with no match. Keep to 3-5 lines max.

---

## Additional Reference Files

- **bug-log.md** — Known issues, resolved bugs, diagnosis checklist
- **feature-log.md** — Feature index with implementation status
- **ui-decisions.md** — Confirmed UI/UX patterns and dashboard decisions
- **prompt-history.md** — Development session history and major milestones

Load as needed based on the task type (see "When to Load" table above).

---

## Quick Troubleshooting Guide

| Symptom | First Check |
|---|---|
| API returns empty/wrong data | Verify variable code, L3 region, date range; check `core-api.md` |
| Raster download fails | Check GDAL config; see `utilities.md` |
| CRS/projection error | Run `wapor_fix_proj()` on Windows; see `utilities.md` |
| Analysis module crash | Check crop mask harmonization; see `analysis-pipeline.md` |
| Dashboard UI not updating | Check reactive dependencies; see `shiny-dashboard.md` |
| Unit conversion wrong | Verify temporal resolution metadata; see `utilities.md` |
| Memory error on large area | Enable incremental mode; see `analysis-pipeline.md` |

For detailed diagnosis: load `bug-log.md` and the relevant module reference file.
