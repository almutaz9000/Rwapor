# Rwapor — Shiny Dashboard
_Module: Interactive UI and dashboard modules_

> Shiny app structure, modules, and UI/UX patterns.
> Load when working on UI changes, dashboard features, or module interactions.

---

## inst/shiny/app.R — Main Dashboard Layout

**Framework**: `bslib::page_navbar` + Bootstrap 5 "flatly" theme  
**Version**: Dashboard launched via `run_wapor()` from R/run_dashboard.R  
**3 tabs**: Download | Visualisation | Analysis  

**Module wiring:**
```r
dl_out <- mod_download_server("dl", l3_regions_meta)
an_out <- mod_analysis_server("an", global_folder = dl_out$folder, aoi_region = dl_out$region)
mod_visualisation_server("vis", global_folder = dl_out$folder, aoi_region = dl_out$region, ...)
```

**Shared state pattern**: `dl_out$folder` and `dl_out$region` reactives are passed from Download module to Analysis and Visualisation modules as the single source of truth.

**Theme customization:**
- Bootswatch: "flatly"
- Primary color: `#2c3e50`
- Tab icons: cloud-download | chart-area | flask
- Exit button (top-right) calls `stopApp()`

---

## inst/shiny/mod_download.R — Data Download Tab

**UI exports:** `mod_download_ui(id, all_vars, default_var, l3_region_choices)`  
**Server exports:** `mod_download_server(id, l3_regions_meta)`  
**Returns:** `list(folder = reactive, region = reactive)`  

**Key UI controls:**
- Variable selector (dropdown with search)
- Period inputs (dateRangeInput)
- L3 region dropdown
- Local folder browser (`shinyFiles::shinyDirButton`)
- Download action button

**Workflow:**
1. User selects variable, date range, region, and folder
2. On Download button click → calls `wapor_map()` in background
3. Shows progress notifications
4. Updates `dl_out$folder` and `dl_out$region` reactives
5. Other tabs consume these reactives

---

## inst/shiny/mod_visualisation.R — Interactive Map Tab

**UI exports:** `mod_visualisation_ui(id)`  
**Server exports:** `mod_visualisation_server(id, global_folder, aoi_region, ...)`  

**Key features:**
- Leaflet interactive map with base layers (OSM, Satellite)
- Dynamic raster layer rendering from local folder
- Variable and date selectors
- Color palette controls
- Layer opacity slider
- Draw tools for AOI selection (via `leaflet.extras2`)

**Workflow:**
1. Scans `global_folder()` for available rasters
2. User selects variable and date
3. Raster loaded with `terra::rast()` and rendered with `leaflet::addRasterImage()`
4. Region outline (from `aoi_region()`) overlaid if available

---

## inst/shiny/mod_analysis.R — Seasonal Analysis Tab (~2400 lines)

**UI exports:** `mod_analysis_ui(id, all_vars, l3_region_choices)`  
**Server exports:** `mod_analysis_server(id, global_folder, aoi_region)`  

**Largest and most complex module** — full seasonal water productivity analysis pipeline.

### Key UI Controls

**Input toggles:**
- `an_use_crop_mask` — Enable per-class crop analysis (checkbox)
- `an_use_season_rasters` — Use pixel-wise season dates (checkbox)

**Fixed season inputs** (when season rasters OFF):
- `an_season_start` — Season start date
- `an_season_end` — Season end date

**Season raster inputs** (when season rasters ON):
- File pickers for season_start.tif and season_end.tif

**Crop mask inputs** (when crop mask ON):
- File picker for crop_mask.tif
- Per-class Kc parameter assignment table (reactive UI)

**L3 region selector:**
- Dropdown for L3 region code

**Yield/Biomass inputs:**
- Yield value + unit selector (kg/ha, ton/ha, etc.)
- Biomass value + unit selector
- NPP conversion toggle with Harvest Index parameters

**Optimization:**
- `an_incremental` — Memory-optimized layer-by-layer processing (checkbox)
- `an_save_rasters` — Save intermediate rasters to disk (checkbox)

**Action buttons:**
1. `an_validate_btn` — Validate inputs before running
2. `an_run_btn` — Execute full analysis (enabled only after validation)
3. `an_reset_btn` — Clear all analysis state
4. `an_export_btn` — Export results to CSV

### Key Reactive State

```r
an_crop_mask_rast     # reactiveVal(NULL) — loaded crop mask SpatRaster
an_start_rast         # reactiveVal(NULL) — season start SpatRaster
an_end_rast           # reactiveVal(NULL) — season end SpatRaster
an_crop_classes       # reactiveVal(NULL) — extracted class values (integer vector)
an_crop_params        # reactiveVal(NULL) — per-class Kc parameters (data.frame)
an_results            # reactiveVal(NULL) — full analysis output (list)
an_peff_monthly       # reactiveVal(NULL) — monthly Peff data.frame
an_local_vars         # reactive() — scanned local variable inventory
```

### Results Display (navset_card_tab)

**Results tabs:**
- Main Results — AETI, RET, ETc totals; adequacy table
- Adequacy — Adequacy raster preview + histogram
- Eff. Precip — Monthly Peff table + seasonal total
- CWP/BWP — Water productivity metrics per class

**Input preview tabs:**
- Crop Mask — Preview with legend
- Season — Season start/end raster previews
- Classes — Crop class table with assigned Kc parameters

### Analysis Workflow Inside Module

```r
observeEvent(input$an_run_btn, {
  # 1. Scan local folder for AETI, RET, precip dekadal data
  local_vars <- rwapor_scan_local_variables(global_folder())
  
  # 2. Load and harmonize crop mask (if enabled)
  if (use_crop_mask) {
    crop_mask <- rwapor_load_crop_mask(crop_mask_path)
    crop_mask <- rwapor_harmonize_crop_mask(crop_mask, aeti_dekad[[1]])
  }
  
  # 3. Build season weights
  season_weights <- rwapor_build_season_weights_dekad(
    start_date, end_date, an_start_rast(), an_end_rast(), variable
  )
  
  # 4. Load AETI and RET dekadal stacks
  aeti_dekad <- rast(local_aeti_paths)
  ret_dekad <- rast(local_ret_paths)
  
  # 5. Calculate seasonal AETI and RET
  aeti_result <- rwapor_calc_seasonal_aeti_masked(
    aeti_dekad, season_weights, crop_mask, multipliers, incremental = input$an_incremental
  )
  ret_result <- rwapor_calc_seasonal_ret_masked(
    ret_dekad, season_weights, crop_mask, multipliers, incremental = input$an_incremental
  )
  
  # 6. Build Kc curve and calculate ETc
  total_days <- rwapor_compute_total_days_raster(an_start_rast(), an_end_rast())
  kc_dekad <- rwapor_aggregate_kc_dekad(kc_daily, dekad_table, season_start)
  etc_seasonal <- rwapor_calc_seasonal_etc_incremental(
    ret_dekad, season_weights, kc_dekad, multipliers
  )
  
  # 7. Calculate adequacy (ETc-based and P95-based)
  adequacy_etc <- rwapor_calc_adequacy_etc(aeti_result$raster, etc_seasonal)
  p95_table <- rwapor_calc_class_p95_aeti(aeti_result$raster, crop_mask)
  adequacy_p95 <- rwapor_calc_adequacy_p95(aeti_result$raster, crop_mask, p95_table)
  
  # 8. Calculate Peff (if precip data available)
  if (!is.null(precip_ts)) {
    precip_monthly <- rwapor_aggregate_precip_monthly(precip_ts)
    peff_monthly <- rwapor_calc_peff_usda_monthly(precip_monthly$p_monthly_mm)
    peff_seasonal <- rwapor_calc_peff_seasonal(peff_monthly, start_date, end_date)
    an_peff_monthly(peff_monthly)
  }
  
  # 9. Calculate CWP and BWP (if yield/biomass provided)
  if (!is.null(input$an_yield_value)) {
    cwp <- rwapor_calc_cwp(input$an_yield_value, aeti_result$by_class$mean_mm)
  }
  if (!is.null(input$an_biomass_value)) {
    bwp <- rwapor_calc_bwp(input$an_biomass_value, aeti_result$by_class$mean_mm)
  }
  
  # 10. Package results
  an_results(list(
    aeti = aeti_result,
    ret = ret_result,
    etc = etc_seasonal,
    adequacy_etc = adequacy_etc,
    adequacy_p95 = adequacy_p95,
    p95_table = p95_table,
    peff_seasonal = peff_seasonal,
    cwp = cwp,
    bwp = bwp
  ))
})
```

---

## inst/shiny/mod_aoi.R — Area of Interest Selection

**UI exports:** `mod_aoi_ui(id)`  
**Server exports:** `mod_aoi_server(id, ...)`  

**Purpose:** AOI selection via:
- Bounding box drawing on leaflet map
- Vector file upload (shp, gpkg, geojson)
- L3 code direct entry

**Returns:** Reactive with parsed region info (consumed by other modules)

---

## inst/shiny/utils_shiny.R — Shiny Helpers

| Function | Description |
|---|---|
| `log_msg()` | Timestamped console logging for debugging |
| `null_default()` | Return default value if input is NULL |
| `is_l3_code()` | Check if string matches L3 code pattern (e.g., "ETH") |
| `crop_to_region_shiny()` | Shiny-safe version of `crop_to_region()` with progress |
| `extract_bbox_from_feature()` | Extract bounding box from Leaflet draw feature JSON |
| `build_polygon_file()` | Build temporary vector file from coordinate matrix |
| `resolve_draw_fun()` | Resolve Leaflet draw function by installed package version |

---

## R/run_dashboard.R — Dashboard Entry Point

| Function | Description |
|---|---|
| `run_wapor()` | Launch Shiny dashboard | No parameters; opens dashboard in browser or RStudio viewer |

**Usage:**
```r
library(Rwapor)
run_wapor()
```

---

## UI/UX Confirmations (from ui-decisions.md)

| Decision | Status |
|---|---|
| bslib page_navbar + Bootstrap 5 "flatly" | ✅ Confirmed |
| Three-tab layout (Download \| Vis \| Analysis) | ✅ Confirmed |
| Shared state via dl_out reactives | ✅ Confirmed |
| Crop mask toggle (optional per-class analysis) | ✅ Confirmed |
| Pixel-wise season rasters toggle | ✅ Confirmed |
| Incremental memory optimization toggle | ✅ Confirmed |
| Validate → Run → Reset → Export button flow | ✅ Confirmed |
| shinyjs for UI state control | ✅ Confirmed |
| shinyFiles for folder browser | ✅ Confirmed |
| leaflet + leaflet.extras for interactive map | ✅ Confirmed |
| navset_card_tab for results display | ✅ Confirmed |

---

## Common UI Patterns

### Conditional UI rendering with shinyjs
```r
observeEvent(input$an_use_crop_mask, {
  if (input$an_use_crop_mask) {
    shinyjs::show("crop_mask_inputs")
    shinyjs::enable("an_validate_btn")
  } else {
    shinyjs::hide("crop_mask_inputs")
  }
})
```

### Dynamic table generation for per-class Kc
```r
output$an_crop_params_table <- renderUI({
  req(an_crop_classes())
  classes <- an_crop_classes()
  
  tagList(
    lapply(classes, function(cls) {
      div(
        h5(paste("Class", cls)),
        numericInput(paste0("kc_ini_", cls), "Kc_ini", value = 0.3),
        numericInput(paste0("kc_mid_", cls), "Kc_mid", value = 1.0),
        numericInput(paste0("kc_end_", cls), "Kc_end", value = 0.6)
      )
    })
  )
})
```

### Progress notifications
```r
withProgress(message = "Running seasonal analysis...", {
  incProgress(0.1, detail = "Loading rasters")
  # ... analysis code ...
  incProgress(0.5, detail = "Calculating AETI")
  # ... more code ...
  incProgress(1.0, detail = "Complete")
})
```

---

## Troubleshooting Dashboard Issues

| Issue | Diagnosis |
|---|---|
| Module not updating | Check reactive dependencies; add `req()` guards |
| Validation not working | Check if all required inputs have values; `req()` fails silently |
| Analysis button stays disabled | Check validation logic; `shinyjs::toggleState()` may be stuck |
| Map not rendering | Check if raster exists; leaflet may fail silently on invalid data |
| Per-class table missing | Check if `an_crop_classes()` is NULL; need to extract classes first |
| Memory crash on large area | Enable `an_incremental` toggle; reduce date range |
| Slow responsiveness | Check if large rasters loading synchronously; use `future` for long ops |
