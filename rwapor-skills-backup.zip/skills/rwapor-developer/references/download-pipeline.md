# Rwapor — Download Pipeline
_Module: Data acquisition and time slice planning_

> Main download functions and optimal resolution planning logic.
> Load when working with `wapor_map()`, `wapor_ts()`, or seasonal download optimization.

---

## R/wapor_map.R

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `wapor_map()` | Download & save raster maps for a region/period | `region`, `variable`, `period`, `folder`, `unit_conversion`, `seasonal`, `download_locally`, `parallel`, `batching`, `batch_size` | Writes GeoTIFF files; returns file paths |

**Key parameters:**
- `region`: bbox matrix, sf object, vector file path, or L3 code string
- `variable`: WaPOR code like `"L3-AETI-D"` or AgERA5 like `"AGERA5-ET0-D"`
- `period`: list with `start` and `end` dates (YYYY-MM-DD)
- `seasonal = TRUE`: triggers optimal mixed-resolution planning
- `parallel = TRUE`: uses `future.apply` for concurrent downloads
- `batching = TRUE`: splits downloads into chunks of `batch_size`

**Notes:**
- Supports WaPOR L1/L2/L3 and AgERA5 variables
- `seasonal=TRUE` triggers `download_seasonal_rasters()` internally
- Parallel mode requires `future::plan()` to be set by user
- Files saved as: `{folder}/{variable}_{date}.tif`

---

## R/wapor_ts.R

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `wapor_ts()` | Extract time series with zonal statistics for polygons/bbox | `region`, `variable`, `period`, `identifier`, `unit_conversion`, `seasonal`, `download_locally`, `parallel`, `batching`, `batch_size` | data.frame with date, value, [identifier] columns |

**Key differences from wapor_map():**
- Returns data.frame instead of file paths
- Uses `exactextractr` for pixel-weighted zonal statistics
- `identifier` names the polygon grouping column (default: "feature_id")
- If `region` is multi-polygon sf, extracts one row per polygon per date

**Notes:**
- Supports same seasonal mode as `wapor_map()`
- For large polygons, pixel-weighted stats are much slower than simple mean
- Can optionally save intermediate rasters if `download_locally=TRUE`

---

## R/plan_wapor_time_slices.R

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `plan_wapor_time_slices()` | Build optimal mixed-resolution download plan | `start_date`, `end_date`, `avail` (temporal codes), `inclusive` | data.frame: one row per raster slice, with `temporal_code`, `date`, `weight`, `multiplier` |
| `get_available_temporal_codes()` | List temporal codes available for a variable | `variable` | character vector e.g. `c("A","M","D")` |

**Example output:**
```r
plan_wapor_time_slices("2020-01-01", "2020-12-31", avail = c("A","M","D"))
#   temporal_code       date weight multiplier
# 1             A 2020-01-01   1.00   1.000000
```

**Planning logic:**
1. Prefers coarser resolution (A > M > D > E) for fully-covered periods
2. Uses finer resolution for partial periods at start/end
3. Computes fractional weights for partial months/years
4. Applies multipliers to avoid double-counting

**Notes:**
- Does NOT download — downstream functions use the plan to fetch data
- Fractional weights assume uniform daily distribution (documented limitation)
- `inclusive = FALSE` excludes partial periods at boundaries

---

## R/seasonal_download.R

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `download_seasonal_rasters()` | (internal) Download and match rasters to plan | `variable`, `period`, `l3_code`, `reg_info`, `folder`, `do_mask` | list: `$groups` (one per temporal code) with rasters + multipliers |

**Internal workflow:**
1. Calls `plan_wapor_time_slices()` to get optimal plan
2. Generates URLs per temporal code via `wapor_generate_urls()`
3. Downloads rasters (parallelized if `future::plan()` set)
4. Crops/masks to region if `do_mask=TRUE`
5. Returns grouped by temporal resolution with weights/multipliers

**Output structure:**
```r  
list(
  groups = list(
    list(
      temporal_code = "A",
      rasters = SpatRaster stack,
      multipliers = numeric vector,
      weights = numeric vector
    ),
    ...
  )
)
```

---

## R/interval_helpers.R

Date arithmetic utilities for seasonal planning:

| Function | Description |
|---|---|
| `subtract_interval()` | Subtract covered intervals from a date range |
| `compute_overlap()` | Compute overlap days between two date ranges |
| `is_fully_within()` | Check if inner interval is fully within outer |
| `last_day_of_month()` | Get last day of a given year/month |

**Used by:** `plan_wapor_time_slices()` for date range calculations

---

## Common Download Patterns

### Simple raster download (no seasonality)
```r
paths <- wapor_map(
  region = "ETH",  # L3 code
  variable = "L3-AETI-D",
  period = list(start = "2020-01-01", end = "2020-03-31"),
  folder = "output/rasters",
  seasonal = FALSE
)
```

### Seasonal download with optimal resolution
```r
paths <- wapor_map(
  region = bbox_matrix,
  variable = "L3-AETI-D",
  period = list(start = "2020-01-01", end = "2020-12-31"),
  folder = "output/seasonal",
  seasonal = TRUE,
  parallel = TRUE
)
```

### Time series extraction for polygons
```r
ts_df <- wapor_ts(
  region = "path/to/polygons.shp",
  variable = "L2-NPP-D",
  period = list(start = "2020-01-01", end = "2020-12-31"),
  identifier = "admin_name",
  seasonal = FALSE
)
```

---

## Troubleshooting

| Issue | Diagnosis |
|---|---|
| URLs not found | Check variable code, L3 region, and date range validity |
| Parallel download slow | Check `future::plan()` setup; try `batch_size` tuning |
| Disk space error | Large seasonal downloads can be 10+ GB; check space first |
| CRS mismatch | Region bbox/vector must be in WGS84 (EPSG:4326) |
| Memory error | Use `seasonal=TRUE` or reduce date range |
