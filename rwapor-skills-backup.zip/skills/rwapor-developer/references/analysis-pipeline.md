# Rwapor — Analysis Pipeline
_Module: Seasonal water productivity indicators_

> Crop mask, season rasters, Kc curves, ETc, AETI, Peff, adequacy, CWP, BWP.
> Load when working with seasonal analysis functions or indicator calculations.

---

## R/analysis.R — Crop & Season Management

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `rwapor_load_crop_mask()` | Load crop mask raster from file | `path` | SpatRaster |
| `rwapor_load_season_raster()` | Load season start/end raster from file | `path` | SpatRaster |
| `rwapor_harmonize_to_template()` | Reproject/resample raster to match template | `x`, `template`, `method` | SpatRaster |
| `rwapor_harmonize_crop_mask()` | Align crop mask to target raster grid | `crop_mask`, `target_raster` | SpatRaster |
| `rwapor_extract_crop_classes()` | Extract unique class values from crop mask | `crop_mask`, `exclude_nodata`, `min_pixels`, `nodata_values` | integer vector |
| `rwapor_build_crop_assignment_table()` | Map crop class values to crop defaults | `class_values`, `crop_defaults` | data.frame |

**Notes:**
- All rasters internally processed with `terra` (never `raster` package)
- Harmonization uses nearest-neighbor for crop masks, bilinear for continuous data
- Class extraction excludes NA and 0 by default

---

## R/analysis.R — Season Mask & Weights

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `rwapor_continuous_julian()` | Convert date to continuous Julian day | `date`, `reference_year` | numeric |
| `rwapor_build_season_mask_daily()` | Build daily binary season mask raster | `dates`, `start_raster`, `end_raster` | SpatRaster (multi-layer) |
| `build_dekad_table()` | Build lookup table of dekadal periods | `start_date`, `end_date` | data.frame |
| `rwapor_build_season_weights_dekad()` | Compute dekadal season weights (0–1) | `start_date`, `end_date`, `start_raster`, `end_raster`, `variable` | SpatRaster |
| `rwapor_compute_total_days_raster()` | Total season days per pixel | `start_raster`, `end_raster` | SpatRaster |
| `rwapor_compute_ldev_raster()` | Compute Ldev (initial development length) | `total_days_raster`, `L_ini_days` | SpatRaster |

**Season weight logic:**
- Each dekad gets weight between 0 and 1 based on overlap with pixel-wise season
- Weight = (days of dekad within season) / (total days in dekad)
- Used to properly aggregate dekadal AETI/RET/NPP over spatially variable seasons

---

## R/analysis.R — Kc Curve Builder (FAO-56)

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `rwapor_build_daily_kc()` | Build daily Kc time series from FAO-56 parameters | `Kc_ini`, `Kc_mid`, `Kc_end`, `L_ini`, `L_dev`, `L_mid`, `L_late` | numeric vector |
| `rwapor_build_kc_by_class()` | Build Kc per crop class | `crop_assignment`, `total_days` | list of numeric vectors |
| `rwapor_aggregate_kc_dekad()` | Aggregate daily Kc to dekadal values | `kc_daily`, `dekad_table`, `season_start` | numeric vector |

**Kc curve phases** (FAO-56 methodology):
1. **Initial** (L_ini days): Constant Kc_ini
2. **Development** (L_dev days): Linear increase from Kc_ini to Kc_mid
3. **Mid-season** (L_mid days): Constant Kc_mid
4. **Late** (L_late days): Linear decrease from Kc_mid to Kc_end

**Data source:** `fao_crop_coefficients.csv` and `fao_growth_stages.csv` (package root)

---

## R/analysis.R — Local Data Management

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `rwapor_scan_local_variables()` | Scan folder for locally downloaded WaPOR files | `folder` | data.frame with variable, dates, paths |
| `rwapor_compare_geom()` | Check if two rasters share same geometry | `r1`, `r2` | logical |
| `rwapor_get_local_rasters()` | Get local raster paths for variable/date range | `folder`, `variable`, `start_date`, `end_date` | character vector of paths |
| `rwapor_check_local_files()` | Check which URLs already exist locally | `urls`, `var`, `folder` | list: present/missing |

---

## R/analysis_indicators.R — Core Aggregation

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `rwapor_apply_masked_sum()` | Weighted sum of raster stack (core aggregation engine) | `x`, `weights`, `layer_multipliers`, `incremental` | SpatRaster (1 layer) |

**Most important function in the package** — all seasonal aggregation uses this.

**Parameters:**
- `x`: SpatRaster stack (e.g., dekadal AETI layers)
- `weights`: SpatRaster (same nlyr as x) with per-pixel per-layer weights (0–1)
- `layer_multipliers`: numeric vector (length = nlyr(x)) for partial period scaling
- `incremental = TRUE`: processes layer-by-layer to reduce peak memory

**Formula per pixel:**
```
result = SUM( x[[i]] * weights[[i]] * layer_multipliers[i] )
```

---

## R/analysis_indicators.R — AETI, RET, NPP Aggregation

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `rwapor_calc_seasonal_aeti_masked()` | Seasonal AETI sum using dekadal weights | `aeti_dekad`, `season_weights`, `crop_mask`, `layer_multipliers`, `incremental` | list: `$raster`, `$by_class` |
| `rwapor_calc_seasonal_ret_masked()` | Seasonal RET sum using dekadal weights | `ret_dekad`, `season_weights`, `crop_mask`, `layer_multipliers`, `incremental` | list: `$raster`, `$by_class` |

**Output structure:**
```r
list(
  raster = SpatRaster,         # Full seasonal raster
  by_class = data.frame(       # Per-class zonal stats
    class = integer,
    mean_mm = numeric,
    median_mm = numeric,
    n_pixels = integer
  )
)
```

---

## R/analysis_indicators.R — ETc & Adequacy

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `rwapor_calc_etc_dekad()` | Dekadal ETc = RET × Kc | `ret_dekad`, `kc_dekad` | SpatRaster |
| `rwapor_calc_seasonal_etc_incremental()` | Seasonal ETc using incremental weighted sum | `ret_dekad`, `season_weights`, `kc_dekad`, `layer_multipliers` | SpatRaster (1 layer) |
| `rwapor_calc_adequacy_etc()` | Adequacy = AETI / ETc | `aeti_seasonal`, `etc_seasonal` | SpatRaster or numeric |
| `rwapor_calc_class_p95_aeti()` | P95 AETI per crop class (benchmark) | `aeti_seasonal`, `crop_mask`, `min_pixels` | data.frame: class, p95_aeti, n_pixels, valid |
| `rwapor_calc_adequacy_p95()` | P95-based adequacy raster | `aeti_seasonal`, `crop_mask`, `p95_table` | SpatRaster |

**Two adequacy methods:**
1. **ETc-based**: Adequacy = AETI / ETc (standard FAO-56 approach)
2. **P95-based**: Adequacy = AETI / P95(AETI) per crop class (benchmark top performers)

---

## R/analysis_indicators.R — Effective Rainfall (USDA SCS)

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `rwapor_aggregate_precip_monthly()` | Aggregate daily/dekadal precip to monthly totals | `precip_ts` (data.frame: date, value) | data.frame: year, month, p_monthly_mm |
| `rwapor_calc_peff_usda_monthly()` | USDA SCS effective rainfall from monthly totals | `p_monthly` (numeric vector, mm) | numeric vector of monthly Peff (mm) |
| `rwapor_calc_peff_seasonal()` | Seasonal Peff total from monthly Peff | `peff_monthly`, `start_date`/`end_date` OR `season_months`+`season_year` | numeric (mm) |

**USDA SCS method** (from FAO-56 Annex 7):
- Peff = 0.8 * P - 25  if P > 75 mm/month
- Peff = 0.6 * P - 10  if P ≤ 75 mm/month
- Peff ≥ 0 always

---

## R/analysis_indicators.R — Water Productivity

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `rwapor_calc_cwp()` | Crop Water Productivity = yield / AETI | `yield_value`, `aeti_mm`, `yield_unit` | numeric or SpatRaster (kg/m³) |
| `rwapor_calc_bwp()` | Biomass Water Productivity = biomass / AETI | `biomass_value`, `aeti_mm`, `biomass_unit` | numeric or SpatRaster (kg/m³) |
| `rwapor_convert_npp_to_tbp()` | Convert NPP (gC/m²) to TBP (kgDM/ha) | `npp_gc_m2` | numeric |
| `rwapor_calc_yield_npp()` | Estimate yield from NPP using harvest index | `npp_gc_m2`, `MC`, `fc`, `AOT`, `HI` | numeric |

**Unit conversions:**
- CWP: kg/m³ (standard FAO unit)
- BWP: kg/m³
- NPP: gC/m² (WaPOR native) → TBP: kgDM/ha (biomass)
- Yield estimation uses harvest index (HI) method from FAO WaPOR methodology

---

## R/analysis_indicators.R — Time Series Preparation

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `rwapor_prepare_analysis_ts()` | Prepare AETI/RET/precip time series for analysis | `region`, `aeti_var`, `ret_var`, `precip_var`, ... | list of time series data.frames |
| `rwapor_merge_analysis_timeseries()` | Merge AETI, RET, precip time series by date | `aeti_ts`, `ret_ts`, `precip_ts` | merged data.frame |

**Helper functions** for the Shiny dashboard to fetch and align time series data.

---

## Common Analysis Patterns

### Full seasonal analysis workflow
```r
# 1. Load inputs
crop_mask <- rwapor_load_crop_mask("crop_mask.tif")
start_rast <- rwapor_load_season_raster("season_start.tif")
end_rast <- rwapor_load_season_raster("season_end.tif")
aeti_dekad <- rast("aeti_dekad_stack.tif")
ret_dekad <- rast("ret_dekad_stack.tif")

# 2. Build season weights
season_weights <- rwapor_build_season_weights_dekad(
  start_date, end_date, start_rast, end_rast, variable = "L3-AETI-D"
)

# 3. Aggregate AETI and RET
aeti_result <- rwapor_calc_seasonal_aeti_masked(
  aeti_dekad, season_weights, crop_mask, layer_multipliers, incremental = TRUE
)
ret_result <- rwapor_calc_seasonal_ret_masked(
  ret_dekad, season_weights, crop_mask, layer_multipliers, incremental = TRUE
)

# 4. Calculate ETc
total_days <- rwapor_compute_total_days_raster(start_rast, end_rast)
kc_daily <- rwapor_build_daily_kc(Kc_ini, Kc_mid, Kc_end, L_ini, L_dev, L_mid, L_late)
kc_dekad <- rwapor_aggregate_kc_dekad(kc_daily, dekad_table, season_start)
etc_seasonal <- rwapor_calc_seasonal_etc_incremental(
  ret_dekad, season_weights, kc_dekad, layer_multipliers
)

# 5. Calculate adequacy
adequacy <- rwapor_calc_adequacy_etc(aeti_result$raster, etc_seasonal)

# 6. Calculate CWP
cwp <- rwapor_calc_cwp(yield_kgha, aeti_result$by_class$mean_mm, yield_unit = "kg/ha")
```

---

## Troubleshooting

| Issue | Diagnosis |
|---|---|
| Weights sum > 1 per pixel | Check season_weights calculation; dates may overlap |
| ETc NaN values | Kc may be 0 or NA; check crop assignment and Kc curve |
| Memory error | Use `incremental=TRUE` in masked_sum functions |
| Adequacy > 1.5 | Check AETI and ETc units; may need scale factor correction |
| P95 benchmark invalid | Class has < min_pixels; increase crop area or lower threshold |
