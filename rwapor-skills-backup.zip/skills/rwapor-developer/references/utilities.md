# Rwapor — Utilities & Helpers
_Module: Support functions, GDAL config, unit conversion, crop defaults_

> Utility functions, system configuration, and helper modules.
> Load when working with utilities, GDAL setup, unit conversion, or crop defaults.

---

## R/utils.R — General Utilities

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `parse_region()` | Parse region input (bbox, vector file, L3 code) | `region` | list with `$type`, `$value` |
| `calculate_conversion_factor()` | Compute unit conversion multiplier | `source_time`, `target_unit`, `num_days`, ... | numeric |
| `extract_temporal_unit()` | Extract temporal unit string from units field | `units` | character |
| `resolve_output_unit_conversion()` | Determine unit conversion rule for variable | `variable`, `unit_conversion` | character |
| `get_seasonal_aggregation_rule()` | Get aggregation rule (sum/mean) for variable | `variable` | character |
| `get_seasonal_multiplier_values()` | Get per-layer multipliers for seasonal aggregation | `variable`, `plan_rows`, `aggregation_rule` | numeric vector |
| `get_analysis_layer_multipliers()` | Get multipliers for analysis pipeline layers | `variable`, `period_table` | numeric vector |
| `get_seasonal_output_units()` | Get output units after seasonal aggregation | `variable`, `aggregation_rule` | character |
| `get_date_info()` | Extract date from WaPOR URL filename | `url`, `tres` | list with date fields |
| `safe_project()` | Safe CRS projection with fallback | `x`, `y` | projected SpatRaster/SpatVector |
| `get_l3_raster_extent()` | Get L3 region raster extent (cached) | `url`, `code` | SpatExtent |
| `guess_l3_region()` | Infer L3 region code from variable + region info | `variable`, `reg_info`, `period` | character |
| `crop_to_region()` | Crop and optionally mask raster to region | `r`, `reg_info`, `do_mask` | SpatRaster |
| `get_url_chunks()` | Split URL list into batches | `urls`, `batching`, `batch_size` | list of URL vectors |
| `assign_raster_metadata()` | Assign units and variable metadata to raster | `r`, `variable`, `unit_conversion`, `units_override` | SpatRaster |

### Region Parsing

`parse_region()` accepts multiple formats:
- **Bounding box matrix**: 2×2 matrix `[[xmin, xmax], [ymin, ymax]]`
- **sf object**: Any `sf` polygon or multipolygon
- **Vector file path**: Character path to .shp, .gpkg, .geojson
- **L3 code**: Character string matching L3 pattern (e.g., "ETH", "AWA", "KEN")

**Output format:**
```r
list(
  type = "bbox" | "vector" | "l3_code",
  value = <parsed object>
)
```

### L3 Extent Caching

`get_l3_raster_extent()` fetches and caches L3 region extents from WaPOR API to avoid repeated HTTP calls. Cache stored in package environment.

**Clear cache:**
```r
Rwapor:::save_l3_extent_cache(list())
```

---

## R/unit_convertor.R — Unit Conversion

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `df_unit_convertor()` | Convert data.frame values between temporal units | `df`, `unit_conversion` | data.frame with converted values |
| `raster_unit_convertor()` | Convert raster values between temporal units | `r`, `variable`, `urls`, `unit_conversion` | SpatRaster with converted values |

**Supported conversions:**
- `mm/day` ↔ `mm/dekad` ↔ `mm/month` ↔ `mm/year`
- `gC/m²/day` ↔ `gC/m²/dekad` ↔ `gC/m²/month` ↔ `gC/m²/year`

**Conversion logic:**
- Assumes uniform distribution within period
- Uses actual day counts per dekad/month (not fixed 10/30)
- Handles leap years correctly

---

## R/gdal_config.R — GDAL & PROJ Setup

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `wapor_configure_gdal()` | Configure GDAL settings for WaPOR downloads | Many options (see below) | invisible (side effects) |
| `wapor_fix_proj()` | Fix PROJ_LIB conflicts on Windows | `verbose` | invisible |
| `wapor_gdal_settings()` | Display current GDAL/PROJ settings | — | prints to console |

### `wapor_configure_gdal()` Parameters

```r
wapor_configure_gdal(
  timeout = 300,              # Download timeout in seconds
  compression = "LZW",        # GeoTIFF compression (LZW, DEFLATE, NONE)
  tiled = TRUE,               # Write tiled GeoTIFFs
  bigtiff = "IF_SAFER",       # BigTIFF mode (YES, NO, IF_NEEDED, IF_SAFER)
  num_threads = "ALL_CPUS",   # GDAL threads
  cache_max = 512,            # GDAL cache size in MB
  disable_readdir_on_open = "EMPTY_DIR",  # Optimize network listing
  http_retry = 3,             # HTTP retry count
  http_retry_delay = 5        # Retry delay in seconds
)
```

**Call once at package load:**
```r
library(Rwapor)
wapor_configure_gdal(timeout = 600, cache_max = 1024)
```

### Windows PROJ_LIB Fix

**Why needed**: On Windows, multiple R packages (sf, terra, rgdal) may set conflicting PROJ_LIB environment variables, causing CRS projection failures.

**Usage:**
```r
wapor_fix_proj(verbose = TRUE)
```

**What it does:**
1. Detects terra's bundled PROJ library
2. Sets `PROJ_LIB` to terra's path
3. Unloads and reloads sf/terra to apply

**Not needed on Linux/Mac** — PROJ typically managed by system package manager.

---

## R/crop_defaults.R — FAO Crop Parameter Management

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `rwapor_list_crops()` | List all available crop names | — | character vector |
| `rwapor_get_crop_defaults()` | Get FAO-56 default parameters for a crop | `crop_name` | list: Kc_ini, Kc_mid, Kc_end, L_ini, L_dev, L_mid, L_late |
| `rwapor_validate_crop_defaults()` | Validate a crop defaults data.frame | `df` | logical (with messages) |

### Crop Parameter Data Sources

**fao_crop_coefficients.csv** (package root):
- Columns: `crop`, `Kc_ini`, `Kc_mid`, `Kc_end`
- Source: FAO-56 Table 12 (Allen et al. 1998)

**fao_growth_stages.csv** (package root):
- Columns: `crop`, `L_ini`, `L_dev`, `L_mid`, `L_late` (days)
- Source: FAO-56 Table 11 (Allen et al. 1998)

**Available crops:** Wheat, Maize, Rice, Sorghum, Barley, Cotton, Sugarcane, Tomato, Potato, Onion, Beans, and many more.

### Usage Example

```r
# List available crops
crops <- rwapor_list_crops()

# Get defaults for maize
maize_params <- rwapor_get_crop_defaults("Maize")
# $Kc_ini: 0.3
# $Kc_mid: 1.2
# $Kc_end: 0.5
# $L_ini: 25
# $L_dev: 40
# $L_mid: 45
# $L_late: 30

# Validate custom crop table
my_crops <- data.frame(
  crop = c("Maize", "Wheat"),
  Kc_ini = c(0.3, 0.3),
  Kc_mid = c(1.2, 1.15),
  Kc_end = c(0.5, 0.4),
  L_ini = c(25, 20),
  L_dev = c(40, 30),
  L_mid = c(45, 55),
  L_late = c(30, 30)
)
rwapor_validate_crop_defaults(my_crops)  # TRUE
```

---

## R/rwapor_favorites.R — Favorites System

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `rwapor_get_favorites()` | List saved favorite folders | — | character vector of paths |
| `rwapor_add_favorite()` | Add a path to favorites | `path`, `type` | invisible |
| `rwapor_remove_favorite()` | Remove a path from favorites | `path` | invisible |
| `rwapor_is_favorite()` | Check if a path is a favorite | `path` | logical |
| `get_favorites_path()` | (internal) Get favorites file path | — | character |

**Purpose:** Persist frequently-used local data folder paths across R sessions.

**Storage:** JSON file at `~/.rwapor/favorites.json`

**Usage in Dashboard:**
- Dropdown of favorites in Download module
- "Add to favorites" button after successful download

---

## Key Dependencies for Utilities

| Package | Usage |
|---|---|
| `terra` | All raster CRS and geometry operations |
| `sf` | Vector/polygon CRS and geometry operations |
| `lubridate` | Date arithmetic for unit conversion |
| `jsonlite` | Favorites system JSON storage |

---

## Common Utility Patterns

### Parse and validate region input
```r
reg_info <- parse_region(region)
if (reg_info$type == "l3_code") {
  extent <- get_l3_raster_extent(url, reg_info$value)
}
```

### Safe CRS projection with fallback
```r
raster_projected <- safe_project(raster_wgs84, target_crs)
```

### Unit conversion pipeline
```r
# Convert raster from mm/dekad to mm/month
r_monthly <- raster_unit_convertor(
  r = raster_dekad,
  variable = "L3-AETI-D",
  urls = urls,
  unit_conversion = "month"
)

# Convert data.frame from mm/day to mm/year
df_annual <- df_unit_convertor(
  df = df_daily,
  unit_conversion = "year"
)
```

---

## Troubleshooting Utilities

| Issue | Diagnosis |
|---|---|
| Region parsing fails | Check format; bbox must be 2×2 matrix in [[xmin,xmax],[ymin,ymax]] |
| CRS reprojection error | Run `wapor_fix_proj()` on Windows; check PROJ_LIB |
| L3 extent cache stale | Clear cache: `Rwapor:::save_l3_extent_cache(list())` |
| Unit conversion wrong | Check variable temporal resolution; verify `get_date_info()` output |
| Favorites not persisting | Check write permissions for `~/.rwapor/` directory |
