# Rwapor — Core API & Metadata
_Module: Core data access layer_

> Low-level API client, metadata management, and variable definitions.
> Load when working with API calls, metadata lookups, or variable definitions.

---

## R/api_client.R

| Function | Description | Key inputs | Output |
|---|---|---|---|
| `collect_responses()` | Fetch paginated WaPOR API responses | `url`, `info` | list of API results |
| `wapor_generate_urls_internal()` | Generate download URLs for WaPOR/AgERA5 resources | `variable`, `l3_region`, `period` | character vector of URLs |
| `wapor_generate_urls()` | Memoised wrapper for `wapor_generate_urls_internal()` | same | character vector (cached) |

**Notes:**
- All API calls use `httr2` for HTTP requests
- Responses are automatically paginated via `collect_responses()`
- `wapor_generate_urls()` uses `memoise` for caching - clears on package reload

---

## R/metadata.R

| Object / Function | Description |
|---|---|
| `WAPOR3_VARS` | Named list of all WaPOR v3 variables (L1/L2/L3) with units, scale factors |
| `AGERA5_VARS` | Named list of all AgERA5 variables with units, scale factors |
| `L3_REGIONS` | Named list of all L3 region codes with name + country |
| `FAO_CROP_DEFAULTS` | Named list of default FAO crop parameters |
| `get_variable_metadata()` | Memoised function: returns metadata for any variable code |
| `get_variable_metadata_internal()` | (internal) actual metadata fetcher from API + static lists |

**Key variable code format**: `"L1-AETI-D"`, `"L2-NPP-A"`, `"L3-AETI-D"`, `"AGERA5-ET0-D"`

**Temporal codes**: `E`=daily, `D`=dekadal, `M`=monthly, `A`=annual

**Metadata structure** (returned by `get_variable_metadata()`):
```r
list(
  code = "L3-AETI-D",
  units = "mm/day",
  scale = 0.1,          # Multiply raw values by this
  temporal_resolution = "dekadal",
  spatial_resolution = "100m",
  available_periods = list(...)
)
```

---

## Key Dependencies for Core API

| Package | Usage |
|---|---|
| `httr2` | All WaPOR API HTTP requests |
| `memoise` | Caching API responses and metadata lookups |
| `jsonlite` | Parsing API JSON responses |

---

## Common API Patterns

### Fetching variable metadata
```r
meta <- get_variable_metadata("L3-AETI-D")
units <- meta$units
scale_factor <- meta$scale
```

### Generating download URLs
```r
urls <- wapor_generate_urls(
  variable = "L3-AETI-D",
  l3_region = "ETH",
  period = list(start = "2020-01-01", end = "2020-12-31")
)
```

### Manual API pagination (if needed)
```r
base_url <- "https://api.fao.org/wapor/v2/..."
results <- collect_responses(base_url, info = list(page = 1, per_page = 100))
```

---

## Troubleshooting

| Issue | Diagnosis |
|---|---|
| Metadata returns NULL | Check if variable code is valid; check API connectivity |
| URLs empty/wrong | Verify l3_region code matches variable level; check date format |
| API timeout | Check network; may need to increase `httr2` timeout |
| Stale cache | Clear memoised cache: `memoise::forget(wapor_generate_urls)` |
